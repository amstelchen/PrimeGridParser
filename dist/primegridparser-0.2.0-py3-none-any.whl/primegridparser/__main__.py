from .PrimeGridParser import main, parse_url

if __name__ == "__main__":
    main()